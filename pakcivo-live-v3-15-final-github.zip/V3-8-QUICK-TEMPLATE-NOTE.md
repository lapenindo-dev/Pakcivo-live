# Pak Civo v3.8 — Quick Template Sales Update

Update ini mengganti quick template awal menjadi 9 tombol yang lebih fokus conversion:

1. 🔥 Produk Paling Dicari
2. 💰 Promo Hari Ini
3. 🥓 Favorit Pelanggan
4. 👨‍🍳 Rekomendasi Pak Civo
5. 🍖 Paket BBQ
6. 🏪 Cabang Terdekat
7. 🚚 Pengiriman & Ongkir
8. 📦 Semua Produk
9. 💬 Hubungi Admin

Setiap tombol memiliki respons lokal cepat dengan hook pembelian natural, tanpa menampilkan SKU dan tanpa klaim stok/promo palsu.
