# 📋 RINGKASAN PROJECT — Pak Civo × CIVO MEAT
> Untuk melanjutkan di sesi chat baru, tulis: "Lanjutan project Pak Civo CIVO MEAT"
> dan lampirkan/rujuk file ini bila perlu.

## Status: MVP Test-Live SIAP DEPLOY (12 Juni 2026)

## Apa itu Pak Civo
AI sales host (butcher virtual) untuk toko online CIVO MEAT. Menyapa customer,
merekomendasikan produk, menghitung porsi, mengelola keranjang, upsell diskon,
dan mengarahkan order. Versi sekarang: order final via WhatsApp (belum Shopify).

## Isi Paket (pakcivo-live.zip)
- public/index.html — halaman chat (banner 4 baris + logo, bubble krem premium)
- public/civo-logo.png — logo krem transparan (dikonversi dari logo hitam)
- api/chat.js — server proxy aman (API key tersembunyi) + SYSTEM PROMPT lengkap
- PANDUAN-DEPLOY.md — langkah deploy ke Vercel

## Knowledge Base v1 (tertanam di api/chat.js)
PRODUK (semua FROZEN):
1. Samcan Pork Belly Lokal — 1kg — Rp 130.000
2. Babi Giling — 500g — Rp 40.000
3. Pork Shoulder Kapsim — 1kg — Rp 80.000
4. Pork Paikut Ribs Chopped — 500g — Rp 50.000
5. Samcan Pork Belly Import — 1kg — Rp 150.000

LOKAL vs IMPORT (fakta saja, TANPA mengarahkan — customer yang pilih):
- Lokal: lemak lebih banyak, lebih juicy (beku belum lama), kadang ada sisa bulu
- Import: layer berlapis & konsisten, bulu bersih, kulit tipis, frozen lebih lama

ATURAN UTAMA: tidak berspekulasi, tidak mengarang, tidak nego diskon,
tidak beri saran medis, eskalasi ke admin bila di luar knowledge base.

DISKON BERTINGKAT (otomatis):
Rp 500rb = 3% | 501rb–1jt = 4% | 1jt–2jt = 5% | >2jt = 6% | <500rb = tanpa diskon
+ Upsell otomatis saat cart mendekati tier berikutnya.

OPERASIONAL:
- Area: Jakarta & Tangerang. Bandung: ada cabang (kontak detail MENYUSUL,
  sementara arahkan ke admin).
- Instan (order maks 16.00) & Same day (order maks 14.00)
- Ongkir: otomatis Grab/Gojek via Shopify (jangan sebut nominal)
- QRIS, tanpa minimum order
- Custom slice: bisa, min 5–10kg, via admin
- Komplain: foto ke WA admin, maks 2×24 jam
- WA Admin: 0817-1717-9291 (di kode: 62817171791 — VERIFIKASI!)
- Panggilan customer: "Kak"
- Penyimpanan (USDA): freezer 4–12 bln (giling ±4 bln); thaw di kulkas bawah;
  setelah thaw masak 3–5 hari (giling 1–2 hari)

## Desain Final
- Tema: arang gelap + merah wine + tembaga + krem (premium butchery)
- Banner compact horizontal: logo + CIVO MEAT / "Best Pork for Every Table" / "🚚 Instan & Same day —
  Jakarta & Tangerang" / "✨ Diskon s.d. 6% · QRIS · Tanpa minimum order"
- Saat chat dimulai: banner MENGECIL (teks tetap tampil, tidak hilang)
- Bubble Pak Civo: krem "butcher paper" dengan teks gelap; bubble customer:
  merah wine berkilau
- Quick start chips, progress bar diskon, cart drawer dengan tombol
  "Order via WhatsApp" berisi rincian otomatis

## Langkah Berikutnya
1. [USER] Deploy test: ikuti PANDUAN-DEPLOY.md (Vercel + API key Gemini)
2. [USER] Kirim data cabang CIVO MEAT (kota, alamat, telp) → update knowledge base
3. [USER] Tambah produk baru (samcan dadu, samcan slice, dll)
4. [NANTI] Integrasi Shopify Storefront API: katalog live, cart asli, checkout
   QRIS + ongkir otomatis; diskon bertingkat via Shopify Functions
5. [NANTI] Fase 2: voice (ElevenLabs), avatar photorealistic (HeyGen/Tavus)

## Keputusan Penting yang Sudah Dibuat
- Platform: TETAP Shopify (volume 100–200 order/hari, backend kuat)
- Flow: Pak Civo isi keranjang → customer checkout sendiri di Shopify
- Pak Civo di-host terpisah (Vercel), bukan app Shopify berbayar
- Test live dulu TANPA Shopify (order via WA) sebelum integrasi penuh


## Update v2 — Product Catalog dengan SKU

Konsep produk sudah dirapikan: customer melihat Nama Produk → Harga/Isi. SKU tetap tersimpan di data produk sebagai field internal untuk integrasi Shopify/inventory, tetapi tidak ditampilkan di chat, keranjang, maupun pesan WhatsApp customer.
