# Update v3.7 — Gemini API Migration

Versi ini mengganti backend AI dari Anthropic/Claude ke Google Gemini API agar biaya operasional lebih ringan untuk test live dan penggunaan jangka panjang.

Environment Variables baru di Vercel:

```env
GEMINI_API_KEY=isi_api_key_google_ai_studio
GEMINI_MODEL=gemini-3.5-flash
```

Environment lama `ANTHROPIC_API_KEY` dan `ANTHROPIC_MODEL` tidak lagi dipakai oleh versi ini.

Catatan: untuk opsi lebih hemat, `GEMINI_MODEL` bisa diganti ke model Flash-Lite yang tersedia di akun Google AI Studio Anda.
