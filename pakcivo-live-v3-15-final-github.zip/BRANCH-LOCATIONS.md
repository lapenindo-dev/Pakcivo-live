# CIVO MEAT Branch Locations — Pak Civo v2

Data cabang sudah ditambahkan ke knowledge base AI Pak Civo.

Pak Civo dapat menjawab pertanyaan customer tentang:
- lokasi cabang,
- alamat,
- Google Maps,
- nomor telepon/WhatsApp cabang.

## Daftar Cabang

1. CIVO MEAT Tangerang Pusat  
Alamat: Daanmogot Arcadia Blok H6 No.3, Batuceper, Kota Tangerang.  
Google Maps: https://maps.app.goo.gl/oD3Hw4vhGArBfRgg7?g_st=aw  
Telp/WA: 0877-6007-0078

2. CIVO MEAT Serpong  
Alamat: Ruko Serpong Park Blok BVA1 No.53, Jelupang, Serpong Utara, Tangerang Selatan.  
Google Maps: https://maps.app.goo.gl/nvswPtdnoW7aewhg6?g_st=aw  
Telp/WA: 0812-8079-9493

3. CIVO MEAT Jakarta Barat  
Alamat: Jl. Perdana 1 Wijaya Kusuma 1 No.1D, Petamburan, Jakarta Barat.  
Google Maps: https://maps.app.goo.gl/fGB5rjps6QjHdFAF6?g_st=aw  
Telp/WA: 0897-9372-211

4. CIVO MEAT Jakarta Pusat  
Alamat: Jl. Kepu Selatan No.29A, Kemayoran, Jakarta Pusat.  
Google Maps: https://maps.app.goo.gl/9aKSQb4yrLfkQmtW7?g_st=aw  
Telp/WA: 0899-8605-577

5. CIVO MEAT Sunter / Jakarta Utara  
Alamat: Jl. Sunter Hijau Raya No.4 Blok F4, Tanjung Priok, Jakarta Utara.  
Google Maps: https://maps.app.goo.gl/gvp2A8zwkom5GLgg6?g_st=aw  
Telp/WA: 0878-7799-9833

6. CIVO MEAT Bandung  
Alamat: Jl. Macan No.20, Lengkong, Kota Bandung, Jawa Barat.  
Google Maps: https://maps.app.goo.gl/uJGDdfqDsBNZdtTP9?g_st=aw  
Telp/WA: 0813-8010-4310

7. CIVO MEAT Semarang  
Alamat: Jl. Petudungan No.95, Jagalan, Semarang Tengah, Kota Semarang.  
Google Maps: https://maps.app.goo.gl/b1aR4XJ1HXxk4d5K9?g_st=ac  
Telp/WA: 0819-5974-3529

8. CIVO MEAT Surabaya  
Alamat: Ruko Jl. Kingstown No.KK-08, Citraland, Sambikerep, Surabaya, East Java 60212.  
Google Maps: https://maps.app.goo.gl/yyHvPvM8Yto6nyhJ7?g_st=ac  
Telp/WA: 0897-9380-066

## Catatan

SKU produk tetap hidden untuk customer dan hanya dipakai internal / Shopify mapping.
