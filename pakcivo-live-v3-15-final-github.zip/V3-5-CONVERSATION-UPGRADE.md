# Pak Civo v3.5 — Conversation & Sales Hook Upgrade

Update utama:
- 30 random greeting berdasarkan waktu (pagi, siang, sore, malam).
- 40 variasi balasan untuk sapaan singkat seperti Halo/Hi/Pagi/Siang/Sore/Malam.
- 20 variasi balasan untuk Terima kasih/Thanks/Makasih.
- 20 variasi balasan untuk Oke/Sip/Baik/Siap.
- 20 variasi balasan untuk Mantap/Keren/Bagus/Cocok.
- Sales hook natural ditambahkan pada balasan ringan agar customer diarahkan ke produk, rekomendasi, cabang terdekat, atau WhatsApp order.
- Prompt AI diperbarui agar setiap jawaban punya hook yang membantu, tanpa memaksa dan tanpa klaim palsu.
- SKU tetap hidden dan hanya untuk internal Shopify/inventory mapping.

Catatan:
- Balasan singkat tertentu dijawab langsung dari frontend agar lebih cepat dan hemat API.
- Pertanyaan produk, lokasi, harga, rekomendasi, cart, dan checkout tetap menggunakan API AI Pak Civo.
