# Pak Civo v3.10 — Header Social Proof + Cart Count

Update:
- Header social proof final: 🔥 Favorit Ribuan Pelanggan Sejak 2016
- Tagline tetap: Best Pork for Every Table
- Menghapus teks pengiriman lama yang terpotong di mobile.
- Keranjang kosong tetap menampilkan angka 0 pada tombol cart.
- Warna chat bubble tidak diubah.
- Mempertahankan Gemini API, quick template sales, random greetings, multi-cabang, Maps, WA cabang, dan SKU hidden.
