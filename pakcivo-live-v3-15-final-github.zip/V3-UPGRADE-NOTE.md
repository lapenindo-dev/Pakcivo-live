# Pak Civo Live v3 — Chef Icon, Branch Locator, Analytics Hook

Update dalam versi ini:

1. Branding chat diganti dari icon pisau menjadi icon chef: 👨‍🍳
2. Sapaan awal diubah menjadi AI Meat Specialist.
3. Area layanan banner diperluas: Jabodetabek, Bandung, Semarang, Surabaya.
4. AI prompt diperkuat agar bisa mendeteksi kota/area customer dan langsung memberi cabang relevan.
5. Google Maps dan WhatsApp cabang tetap tersedia di knowledge base AI.
6. SKU tetap hidden untuk customer.
7. Analytics hook Microsoft Clarity ditambahkan secara opsional.

## Optional: aktifkan Microsoft Clarity

Di Vercel > Settings > Environment Variables, tambahkan:

```env
CLARITY_PROJECT_ID=isi_project_id_clarity
```

Jika kosong, analytics tidak aktif dan aplikasi tetap jalan normal.

## Catatan Admin Produk dan Shopify

Versi ini belum memakai database eksternal agar tetap mudah upload ZIP ke Vercel.
Untuk admin produk tanpa redeploy dan sinkronisasi Shopify berdasarkan SKU, tahap berikutnya perlu database/API, misalnya Supabase atau Shopify Admin API.
