# Pak Civo v3.6 — Tagline & Header Update

Update final:
- Tagline lama "Frozen pork berkualitas" diganti menjadi "Best Pork for Every Table".
- Header/banner dibuat lebih compact dengan layout horizontal: logo di samping teks.
- Warna chat bubble tidak diubah sesuai instruksi terakhir.
- SKU tetap hidden untuk customer.
