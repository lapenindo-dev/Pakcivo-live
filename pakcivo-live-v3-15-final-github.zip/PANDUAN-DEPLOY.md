# 🥩 Pak Civo LIVE — Panduan Deploy (Tanpa Shopify)

Versi uji coba: chat + keranjang + diskon bertingkat.
Checkout sementara diarahkan ke **WhatsApp admin** (sampai integrasi Shopify siap).

---

## Yang Dibutuhkan (sekali saja)

1. **Akun Vercel** (gratis) — daftar di https://vercel.com pakai email/Google
2. **API Key Gemini** — buat di Google AI Studio: https://aistudio.google.com/app/apikey
   - Login Google → Create API Key
   - SIMPAN key-nya, jangan dibagikan ke siapa pun

> 💰 Gemini Flash cocok untuk test dan operasional jangka panjang karena biaya lebih ringan untuk chatbot sales.

---

## Cara Deploy (±10 menit)

### Lewat Website Vercel (paling mudah, tanpa coding)

1. Buka https://vercel.com → login
2. Klik **Add New → Project**
3. Pilih **Upload** (atau hubungkan GitHub kalau paham)
4. Upload seluruh isi folder `pakcivo-live` ini (folder `api/`, `public/`, dan `package.json`)
5. SEBELUM klik Deploy, buka bagian **Environment Variables**:
   - Name: `GEMINI_API_KEY`
   - Value: (tempel API key dari Google AI Studio)
   - Name: `GEMINI_MODEL`
   - Value: `gemini-3.5-flash`
   - Name: `RATE_LIMIT_PER_MINUTE`
   - Value: `15`
   - Name: `RATE_LIMIT_PER_HOUR`
   - Value: `120`
6. Klik **Deploy**
7. Selesai! Vercel memberi alamat seperti `pakcivo-live.vercel.app`

### Alternatif: lewat terminal/Vercel CLI (untuk yang punya laptop + terminal)

```
npm i -g vercel
cd pakcivo-live
vercel
# ikuti prompt, lalu set env:
vercel env add GEMINI_API_KEY
vercel env add GEMINI_MODEL
vercel env add RATE_LIMIT_PER_MINUTE
vercel env add RATE_LIMIT_PER_HOUR
vercel --prod
```

---

## Proteksi Anti-Spam & Captcha

Versi ini sudah punya **rate limit standar** di `api/chat.js`:

- Default maksimal `15` chat per menit per IP
- Default maksimal `120` chat per jam per IP
- Bisa diubah lewat Vercel Environment Variables:
  - `RATE_LIMIT_PER_MINUTE`
  - `RATE_LIMIT_PER_HOUR`

Untuk traffic besar, aktifkan captcha gratis Cloudflare Turnstile:

1. Buka Cloudflare Dashboard → Turnstile → Add site
2. Tambahkan domain Vercel/domain sendiri
3. Copy **Site Key** dan **Secret Key**
4. Di Vercel → Settings → Environment Variables, tambahkan:
   - `CAPTCHA_ENABLED=true`
   - `TURNSTILE_SITE_KEY=isi_site_key`
   - `TURNSTILE_SECRET_KEY=isi_secret_key`
5. Redeploy project

Jika `CAPTCHA_ENABLED` tidak diaktifkan, captcha tidak muncul. Jadi untuk test awal bisa pakai rate limit saja.

---

## Setelah Live — Checklist Test

- [ ] Buka alamat vercel-nya di HP → Pak Civo menyapa otomatis
- [ ] Tap "Mau BBQ weekend ini 🔥" → dia tanya jumlah orang & hitung porsi
- [ ] Setujui pembelian → keranjang terisi (lihat angka 🛒 di pojok berubah)
- [ ] Belanja > Rp 500rb → diskon muncul di keranjang
- [ ] Coba "bisa nego diskon?" → dia menolak sopan
- [ ] Coba "lokasi Surabaya?" → dia memberi alamat, Google Maps, dan WA cabang
- [ ] Klik 🛒 → tombol hijau "Order via WhatsApp" → pesan WA terisi otomatis
      dengan rincian pesanan + total

## ✅ Nomor WhatsApp

Nomor admin sudah diset ke format internasional yang benar:

```
const WA_NUMBER = "6281717179291";
```

Format ini berasal dari 0817-1717-9291 → 6281717179291.

---

## Domain Sendiri (opsional)

Di Vercel: Project → Settings → Domains → tambahkan misalnya
`chat.civomeat.com`, lalu ikuti instruksi DNS-nya. Gratis.

---

## Update Knowledge Base Nanti

Semua "otak" Pak Civo ada di file `api/chat.js` bagian `SYSTEM_PROMPT`.
Mau tambah produk/cabang/aturan → edit file itu → redeploy.
(Atau minta ChatGPT buatkan versi barunya, tinggal ganti file.)

---

## Batasan Versi Test Ini

- ❌ Belum terhubung stok/harga Shopify asli (katalog masih tertanam di kode)
- ❌ Belum ada checkout online — order diselesaikan via WhatsApp
- ✅ Sudah ada rate limit dasar untuk mencegah spam API
- ✅ Captcha ringan gratis bisa diaktifkan saat traffic besar
- ✅ Semua logika percakapan, rekomendasi, porsi, diskon, dan aturan sudah PRODUKSI
- Saat integrasi Shopify nanti, hanya bagian katalog & checkout yang diganti —
  pengalaman customer tetap sama.
