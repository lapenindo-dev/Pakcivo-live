# Product Catalog Note — Pak Civo v2.1

## Prinsip Tampilan Customer

Customer hanya melihat:

1. Nama Produk
2. Isi / satuan
3. Harga

SKU **tidak ditampilkan** di chat, keranjang, maupun pesan WhatsApp order. SKU hanya disimpan sebagai field internal untuk integrasi Shopify, inventory, gudang, dan laporan.

## Struktur Data Internal

Produk tetap disimpan dengan format:

| Nama Produk | SKU Internal | Isi | Harga |
|---|---|---:|---:|
| Samcan Pork Belly Lokal | CIVO-SM-LKL-001 | 1 kg | Rp 130.000 |
| Babi Giling (Pork Ground) | CIVO-BG-500-001 | 500 g | Rp 40.000 |
| Pork Shoulder Kapsim | CIVO-PSK-1KG-001 | 1 kg | Rp 80.000 |
| Pork Paikut Ribs Chopped | CIVO-PRC-500-001 | 500 g | Rp 50.000 |
| Samcan Pork Belly Import | CIVO-SM-IMP-001 | 1 kg | Rp 150.000 |

## Lokasi Update Produk Saat Ini

Sebelum memakai database/Supabase/Shopify live, update katalog di dua tempat:

1. `public/index.html`
   - Edit objek `CATALOG`
   - Urutan field internal: `name`, `sku`, `price`, `unit`
   - SKU tetap hidden dari customer

2. `api/chat.js`
   - Update bagian `PRODUCTS` pada system prompt
   - Tampilkan hanya nama, isi, harga, dan kegunaan produk
   - Jangan menampilkan SKU di prompt customer-facing

## Roadmap Berikutnya

Saat integrasi Shopify dibuat, SKU menjadi kunci pencarian produk/stok/harga di Shopify. Customer tetap melihat nama produk dan harga saja.
