# V3.13 Clickable Links Update

- Google Maps links in Pak Civo chat are now rendered as clickable links.
- Branch WhatsApp numbers are now provided as clickable `wa.me` links in AI responses.
- Frontend safely escapes chat content before linkifying URLs.
